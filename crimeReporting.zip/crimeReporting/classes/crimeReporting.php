<?php
/**
*   @package    Crime Reporting
*   @author     sanket sorathiya
*/

require_once(dirname(dirname(__FILE__)).'/includes/configuration.php');

/**
*   Class: CrimeReporting
*   Some functions related to every processing.
*/
class CrimeReporting extends CrimeReportingConfiguration {

	/** add new package
	*	@one-argument of packages data in array
	*	@if return true 
	*	add new packages in database.
	**/
	public function CRGetCrimeList($status='') {
		$this->connectDB();
		if($status!='') :
			if($status=='completed') :
				$sql = 'SELECT * FROM '.$this->crimeReportTable.' WHERE `status`="'.$status.'"';
			else :
				$sql = 'SELECT * FROM '.$this->crimeReportTable.' WHERE `status`="'.$status.'" OR `status`=""';
			endif;
			$datas = $this->dbSelecte($sql);
			if(!empty($datas)) :
				return count($datas);
			else :
				return 0;
			endif;
		else :
			$sql = 'SELECT * FROM '.$this->crimeReportTable;
			return $this->dbSelecte($sql);
		endif;
		
	}

	public function CRGetTotalCrime() {
		$datas = $this->CRGetCrimeList();
		if(!empty($datas)) :
			return count($datas);
		else :
			return 0;
		endif;
	}
}
$CrimeReporting = new CrimeReporting();
?>