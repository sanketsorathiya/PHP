<?php include('includes/header.php'); ?>
<?php $crimeDatas = $CrimeReporting->CRGetCrimeList(); ?>
<div id="main" role="main">
	<div id="content">
		<div class="row">
			<div class="col-xs-12 col-sm-7 col-md-10 col-lg-4">
				<h1 class="page-title txt-color-blueDark"><i class="fa-fw fa fa-home"></i> Crime Report <span>> Crime List</span></h1>
			</div>
		</div>

		<div class="jarviswidget jarviswidget-color-blueDark" id="wid-id-3" data-widget-editbutton="false">
		<header>
			<span class="widget-icon"> <i class="fa fa-list"></i> </span>
			<h2>Crime List</h2>
		</header>
		<div>

			<div class="jarviswidget-editbox">
				<!-- This area used as dropdown edit box -->

			</div>
			<!-- end widget edit box -->

			<!-- widget content -->
			<div class="widget-body no-padding">
				<table id="datatable_tabletools" class="table table-striped table-bordered table-hover" width="100%">
					<thead>
						<tr>
							<th data-hide="phone">ID</th>
							<th data-class="expand">Category Name</th>
							<th>Crime Info</th>
							<th data-hide="phone">Location</th>
							<th data-hide="phone,tablet">Status</th>
							<th data-hide="phone,tablet">Action</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach($crimeDatas as $crime) : ?>
							<tr>
								<td><?php echo $crime->crime_id; ?></td>
								<td><?php echo $crime->category_name; ?></td>
								<td>
									<?php echo $crime->crime_info; ?>
									<input type="hidden" name="crime-lng" id="crime-lng" value="<?php echo $crime->lng; ?>" />
									<input type="hidden" name="crime-lat" id="crime-lat" value="<?php echo $crime->lat; ?>" />
								</td>
								<td><a href="javascript:void(0);" class="btn btn-primary btn-lg" data-toggle="modal" data-toggle="modal" data-target="#crime-show-map">View</a></td>								
								<td><span class="label label-default">Remaining</span></td>
								<td>
									<span class="handle"> <label class="checkbox">
									<input type="checkbox" name="checkbox-inline" />
									<i></i> </label> </span>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

			</div>
			<!-- end widget content -->

		</div>
		<!-- end widget div -->
		</div>
	</div>
</div>
<head>

    <script src="https://code.jquery.com/jquery-1.10.2.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
    <script src="http://maps.googleapis.com/maps/api/js?key=BIzaSyA1gvGcwg6OPMaLsSutIecjkIXrABV3AoF"></script>
    <script src="<?php echo assetsJS; ?>locationpicker.jquery.min.js"></script>
    <title>Simple example</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

</head>
<div class="modal fade crime-modal-popup" id="crime-show-map" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">
					&times;
				</button>
				<h4 class="modal-title" id="myModalLabel">Crime Map</h4>
			</div>
			<div class="modal-body">
				<div class="form-horizontal" style="width: 100%">
                        <div class="form-group">
                            <label class="col-sm-2 control-label">Location:</label>

                            <div class="col-sm-10">
                                <input type="text" class="form-control" id="us3-address" />
                            </div>
                        </div>
                        <div id="crime-map" style="width: 100%; height: 400px;"></div>
                        <div class="clearfix">&nbsp;</div>
                        
                        <div class="clearfix"></div>
                        <script>
                            jQuery('#crime-map').locationpicker({
                                location: {
                                    latitude: 46.15242437752303,
                                    longitude: 2.7470703125
                                },
                                radius: 300,
                                inputBinding: {
                                    latitudeInput: jQuery('#crime-lat'),
                                    longitudeInput: jQuery('#crime-lng'),
                                },
                                enableAutocomplete: true,
                                markerIcon: 'http://www.iconsdb.com/icons/preview/tropical-blue/map-marker-2-xl.png'
                            });
                            jQuery('#crime-show-map').on('shown.bs.modal', function () {
                                jQuery('#crime-map').locationpicker('autosize');
                            });
                        </script>
                    </div>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
				<button type="button" class="btn btn-primary">Save changes</button>
			</div>
		</div><!-- /.modal-content -->
	</div><!-- /.modal-dialog -->
</div>
<?php include('includes/footer.php'); ?>