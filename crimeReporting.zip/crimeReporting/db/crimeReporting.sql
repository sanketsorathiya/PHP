-- Adminer 4.2.5 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

SET NAMES utf8mb4;

DROP TABLE IF EXISTS `crime_report`;
CREATE TABLE `crime_report` (
  `crime_id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` text NOT NULL,
  `crime_info` text NOT NULL,
  `user_detail` text NOT NULL,
  `device_id` text NOT NULL,
  `lat` text NOT NULL,
  `lng` text NOT NULL,
  `image_url` text NOT NULL,
  `status` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_vietnamese_ci NOT NULL,
  PRIMARY KEY (`crime_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `crime_report` (`crime_id`, `category_name`, `crime_info`, `user_detail`, `device_id`, `lat`, `lng`, `image_url`, `status`) VALUES
(1,	'Abuse/Assault',	'I saw that 4 people come and Kidnap a child and run away in black car',	'Hardik 9473737383',	'ebec70aeeea026d4',	'23.0651707',	'72.5676103',	'http://collective.hol.es/securitygaze/images/578c4e0227fdf.png',	''),
(2,	'Mental Health',	'some people come on bike and snatch the chain of one lady',	'Hardik93838383839',	'ebec70aeeea026d4',	'23.180106',	'72.5023061',	'http://collective.hol.es/securitygaze/images/578d98ff0785e.png',	''),
(3,	'Theft',	'Tires',	'John',	'c9b0ad5e4dc8a396',	'44.6364439',	'-63.5736902',	'http://collective.hol.es/securitygaze/images/578e5e644e890.png',	''),
(4,	'Accident',	'A car accident haoppens',	'Hardik',	'ebec70aeeea026d4',	'23.0653283',	'72.567558',	'http://collective.hol.es/securitygaze/images/5790465d32e9d.png',	''),
(5,	'Drugs/Alcohol',	'Property damage',	'John',	'c9b0ad5e4dc8a396',	'44.6364555',	'-63.5737154',	'http://collective.hol.es/securitygaze/images/57935e2bd6c9d.png',	''),
(6,	'Property Damage',	'Property damage',	'John',	'c9b0ad5e4dc8a396',	'44.6364555',	'-63.5737154',	'http://collective.hol.es/securitygaze/images/57935e34d1adb.png',	''),
(7,	'Abuse/Assault',	'I just witnessed a Abuse/Assault at Champak Nagar, Nava Vadaj, Ahmedabad, Gujarat 380013, India and would like to report it',	'undefined',	'ebec70aeeea026d4',	'23.0651885',	'72.5676025',	'http://collective.hol.es/securitygaze/images/5795835be9b71.png',	''),
(8,	'Abuse/Assault',	'I just witnessed a Abuse/Assault at Champak Nagar, Nava Vadaj, Ahmedabad, Gujarat 380013, India and would like to report it',	'undefined',	'ebec70aeeea026d4',	'23.0651913',	'72.5676031',	'http://collective.hol.es/securitygaze/images/579585d75173b.png',	''),
(9,	'Drugs/Alcohol',	'I just witnessed a Drugs/Alcohol at South End, Halifax, NS, Canada and would like to report it',	'John',	'c9b0ad5e4dc8a396',	'44.6365015',	'-63.5737478',	'http://collective.hol.es/securitygaze/images/5799912938ba3.png',	''),
(10,	'Drugs/Alcohol',	'I just witnessed a Drugs/Alcohol at South End, Halifax, NS, Canada and would like to report it',	'John',	'c9b0ad5e4dc8a396',	'44.6365015',	'-63.5737478',	'http://collective.hol.es/securitygaze/images/5799912d24839.png',	''),
(11,	'Drugs/Alcohol',	'I just witnessed a Drugs/Alcohol at South End, Halifax, NS, Canada and would like to report it',	'John',	'c9b0ad5e4dc8a396',	'44.6365015',	'-63.5737478',	'http://collective.hol.es/securitygaze/images/579991307ac1c.png',	''),
(12,	'Vandalism',	'I just witnessed a Vandalism at South End, Halifax, NS, Canada and would like to report it',	'Saint John',	'c9b0ad5e4dc8a396',	'44.6317644',	'-63.58027040000002',	'http://collective.hol.es/securitygaze/images/5799919619b23.png',	''),
(13,	'Impaired Driving',	'I just witnessed a Impaired Driving at South End, Halifax, NS, Canada and would like to report it',	'John',	'c9b0ad5e4dc8a396',	'44.63815899999999',	'-63.57457999999997',	'http://collective.hol.es/securitygaze/images/579991e11b9f2.png',	''),
(14,	'Impaired Driving',	'I just witnessed a Impaired Driving at South End, Halifax, NS, Canada and would like to report it',	'John',	'c9b0ad5e4dc8a396',	'44.63815899999999',	'-63.57457999999997',	'http://collective.hol.es/securitygaze/images/579991f62c86b.png',	''),
(15,	'Noise Complaints',	'Would like to report a Noise Complaint at this location',	'undefined',	'c9b0ad5e4dc8a396',	'44.6457621',	'-63.5960673',	'http://collective.hol.es/securitygaze/images/579ba62477ee4.png',	'');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` text COLLATE utf8_unicode_ci NOT NULL,
  `password` text COLLATE utf8_unicode_ci NOT NULL,
  `fullname` text COLLATE utf8_unicode_ci NOT NULL,
  `contact_no` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


-- 2016-09-07 17:55:12
