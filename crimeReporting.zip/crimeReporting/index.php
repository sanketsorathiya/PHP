<?php include('includes/header.php'); ?>
<?php $totalCrime = $CrimeReporting->CRGetTotalCrime(); ?>
<?php $totalCompleteCrime = $CrimeReporting->CRGetCrimeList('completed'); ?>
<?php $totalUnompleteCrime = $CrimeReporting->CRGetCrimeList('not-completed'); ?>
		<!-- MAIN PANEL -->
		<div id="main" role="main">

			<!-- RIBBON -->
			<div id="ribbon">

				<span class="ribbon-button-alignment"> 
					<span id="refresh" class="btn btn-ribbon" data-action="resetWidgets" data-title="refresh"  rel="tooltip" data-placement="bottom" data-original-title="<i class='text-warning fa fa-warning'></i> Warning! This will reset all your widget settings." data-html="true">
						<i class="fa fa-refresh"></i>
					</span> 
				</span>

				<!-- breadcrumb -->
				<ol class="breadcrumb">
					<li>Home</li><li>Dashboard</li>
				</ol>
				<span class="ribbon-button-alignment pull-right">
				<span id="search" class="btn btn-ribbon hidden-xs" data-title="search"><i class="fa-grid"></i> Change Grid</span>
				<span id="add" class="btn btn-ribbon hidden-xs" data-title="add"><i class="fa-plus"></i> Add</span>
				<span id="search" class="btn btn-ribbon" data-title="search"><i class="fa-search"></i> <span class="hidden-mobile">Search</span></span>
				</span>

			</div>
			<!-- END RIBBON -->

			<!-- MAIN CONTENT -->
			<div id="content">

				<div class="row">
					<div class="col-xs-12 col-sm-7 col-md-7 col-lg-4">
						<h1 class="page-title txt-color-blueDark"><i class="fa-fw fa fa-home"></i> Dashboard <span>> My Dashboard</span></h1>
					</div>
				</div>
				<div class="row">
					<div class="col-xs-12 col-sm-6 col-md-3">
			            <div class="panel panel-darken">
			                <div class="panel-heading">
			                    <h3 class="panel-title">
			                        Total Crime</h3>
			                </div>
			                <div class="panel-body no-padding text-align-center">
			                	<div class="panel-title">Total Number Of Crimes :</div>
								<h3><?php echo $totalCrime; ?></h3>
			                </div>
			            </div>
			        </div>
			        <div class="col-xs-12 col-sm-6 col-md-3">
			            <div class="panel panel-darken">
			                <div class="panel-heading">
			                    <h3 class="panel-title">
			                        Solved Crime</h3>
			                </div>
			                <div class="panel-body no-padding text-align-center">
			                	<div class="panel-title">Total Solved Crimes :</div>
								<h3><?php echo $totalCompleteCrime; ?></h3>
			                </div>
			            </div>
			        </div>
			        <div class="col-xs-12 col-sm-6 col-md-3">
			            <div class="panel panel-darken">
			                <div class="panel-heading">
			                    <h3 class="panel-title">
			                        Remaining Crime</h3>
			                </div>
			                <div class="panel-body no-padding text-align-center">
			                	<div class="panel-title">Total Remaining Solved Crimes :</div>
								<h3><?php echo $totalUnompleteCrime; ?></h3>
			                </div>
			            </div>
			        </div>
				</div>
				</div>
			</div>
			<!-- END MAIN CONTENT -->

		</div>
		<!-- END MAIN PANEL -->
<?php include('includes/footer.php'); ?>