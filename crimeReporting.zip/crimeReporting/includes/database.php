<?php
/**
*   @package    Crime Reporting
*   @author     sanket sorathiya
*/

// Define default settings use for everywhere.
define('DIRSEP', DIRECTORY_SEPARATOR);
define('basePath', dirname(dirname(__FILE__)).DIRSEP);

/*
*
*   Class: CrimeReportingSetup
*   Some define and set value for database to establishing connection.
*/

class CrimeReportingSetup {

    /** Database Connection Setup **/
    protected $baseUrl      =   'crimeReporting'; // site base directory name if any sub directory use

    protected $dbHost       =   'localhost';      // hostname

    protected $dbName       =   'crimeReporting';   // database name

    protected $dbUser       =   'root';   // database user name

    protected $dbPassword   =   'Nature-207'; // database user password


    /************** USE FOR THE DEVELOPERS ONLY *************/
    /**
    *   asset Url set if change path asset - css, js, images, fonts, etc.. then change it 
    */
    protected $assetsCSS    =   'assets'.DIRSEP.'css'.DIRSEP;  // style sheet

    protected $assetsJS     =   'assets'.DIRSEP.'js'.DIRSEP;    // jquery

    protected $assetsIMG    =   'assets'.DIRSEP.'images'.DIRSEP;   // images

    /* Don't Change The Table name */
    protected $crimeReportTable     =	'crime_report';	// package table

    protected $userTable            =	'users';	// package meta table

    /* Don't Change & add any value Connection */
    protected $connection       =   '';

    /* Debuging mode */
    protected $debugMode        =   true;   // if debug mode true then display any errors.
}
?>