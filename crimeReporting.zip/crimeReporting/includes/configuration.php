<?php
/**
*   @package    Crime Reporting
*   @author     sanket sorathiya
*/
require_once('database.php');

/**
*   Class: CrimeReportingConfiguration
*   Some functions related to establishing a database connection.
*/
class CrimeReportingConfiguration extends CrimeReportingSetup {

    /** constructor
    *   @no-argument
    *   @no-return
    *   set site url.
    **/
    function __construct() {
        define('baseUrl', $this->baseUrl());
        define('assetsCSS', baseUrl.$this->assetsCSS);
        define('assetsJS', baseUrl.$this->assetsJS);
        define('assetsIMG', baseUrl.$this->assetsIMG);

        $this->debugMode($this->debugMode);
    }

    /** base url
    *   @no-argument
    *   @url string-return
    *   return site base url.
    **/
    public function baseUrl() {
        return sprintf(
            "%s://%s/%s",
            isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
            $_SERVER['SERVER_NAME'],
            isset($this->baseUrl) && $this->baseUrl!='' ? $this->baseUrl.DIRSEP : ''
        );
    }

    /** Connect to database
    *   @one-argument debug mode
    *   @no-return value.
    *   set debuging mode.
    **/
    public function debugMode($mode=false) {
        if($this->debugMode==true && $mode==true) :
            ini_set("display_errors", "1");
            error_reporting(E_ALL);
        else :
            ini_set("display_errors", "0");
            error_reporting(0);
        endif;
    }

    /** Connect to database
    *   @no-argument
    *   @if return true connection success else die with display error message.
    *   set establishing database connection.
    **/
    public function connectDB() {
        try {
            $this->connection = mysqli_connect($this->dbHost, $this->dbUser, $this->dbPassword, $this->dbName) OR die('Error establishing a database connection');
        } catch(Exception $e) {
            echo $e->getMessage(); exit;
        }
        return true;
    }

    public function dbInsert($query) {
        $this->connectDB(); $result = array();
        try {
            mysqli_query($this->connection, $query) or die(mysqli_error($this->connection));
            $result['ID'] =  mysqli_insert_id($this->connection);
        } catch(Exception $e) {
            $result['error'] = $e->getTraceAsString();
        }
        return $result;
    }

    public function dbUpdate($query) {
        $this->connectDB(); $result = '';
        try {
            mysqli_query($this->connection, $query) or die(mysqli_error($this->connection));
            $result = true;
        } catch(Exception $e) {
            $result = $e->getTraceAsString();
        }
        return $result;
    }

    public function dbDelete($query) {
        $this->connectDB(); $result = '';
        try {
            mysqli_query($this->connection, $query) or die(mysqli_error($this->connection));
            $result = true;
        } catch(Exception $e) {
            $result = $e->getTraceAsString();
        }
        return $result;
    }

    public function dbSelecte($query) {
        $this->connectDB(); $result = '';
        try {
            $dbQuery = mysqli_query($this->connection, $query) or die(mysqli_error($this->connection));
            if(mysqli_num_rows($dbQuery)) :
                while ($row = mysqli_fetch_object($dbQuery)) {
                    $result[$row->crime_id] = $row;
                }
            endif;
        } catch(Exception $e) {
            $result['error'] = $e->getTraceAsString();
        }
        return $result;
    }



    /** submit package in database
    *   @one-argument of packages data in array
    *   @if return true 
    *   add new packages in database.
    **/
    public function CREscaping($string) {
        return mysqli_real_escape_string($this->connection, $string);
    }

    /** encryption settings datas
    *   @access for relative the family
    *   @one argument datas is array formate $originalDatas
    *   @return Encryption data string result.
    *   call for the any datas encryption formate using serialize & base64_encode
    *   first of array data convert to serialize string after then this string encryption using base64_encode
    **/
    public function CREncryption( $originalDatas ) { 
        return base64_encode(serialize($originalDatas));
    }

    /** decryption settings datas
    *   @access for relative the family
    *   @one argument datas is encrypted formate string $encryptionDatas
    *   @return Decryption data array result.
    *   call for the any original datas encryption formate using base64_decode & unserialize
    *   first of encrypted string data convert to decoding using base64_decode string after then this string encryption using base64_decode
    **/
    public function CRDecryption( $encryptionDatas ) {
        return unserialize(base64_decode($encryptionDatas));
    }

    public function CRException() {
        echo 'Not define the action!';
    }
}
?>