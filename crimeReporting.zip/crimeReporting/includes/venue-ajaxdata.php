<?php
include(dirname(dirname(__FILE__)).'/classes/venue-comparison.php');
$VenueComparison = new VenueComparison();

if(isset($_POST['action']) && !empty($_POST['action'])) {
    $action = $_POST['action'];
    switch($action) {
        case 'addPackage' : 
        	$result = $VenueComparison->VCAddPackage($_POST);
        	echo json_encode($result);
        	break;
        case 'pachageCompare' :
        	echo $VenueComparison->VCPackageCompare($_POST['packages']);
        	break;
        default : $VenueComparison->exception(); break;
    }
    exit;
}
?>