	<script data-pace-options='{ "restartOnRequestAfter": true }' src="<?php echo assetsJS; ?>plugin/pace/pace.min.js"></script>
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script>
		if (!window.jQuery) {
			//document.write('<script src="<?php echo assetsJS; ?>libs/jquery-2.1.1.min.js"><\/script>');
		}
	</script>
	<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.10.3/jquery-ui.min.js"></script>
	<script>
		if (!window.jQuery.ui) {
			//document.write('<script src="<?php echo assetsJS; ?>libs/jquery-ui-1.10.3.min.js"><\/script>');
		}
	</script>

	<!-- IMPORTANT: APP CONFIG -->
	<script src="<?php echo assetsJS; ?>app.config.js"></script>

	<!-- JS TOUCH : include this plugin for mobile drag / drop touch events-->
	<script src="<?php echo assetsJS; ?>plugin/jquery-touch/jquery.ui.touch-punch.min.js"></script> 

	<!-- BOOTSTRAP JS -->
	<script src="<?php echo assetsJS; ?>bootstrap/bootstrap.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/sparkline/jquery.sparkline.min.js"></script>

	<!-- JQUERY VALIDATE -->
	<script src="<?php echo assetsJS; ?>plugin/jquery-validate/jquery.validate.min.js"></script>

	<!-- JQUERY MASKED INPUT -->
	<script src="<?php echo assetsJS; ?>plugin/masked-input/jquery.maskedinput.min.js"></script>

	<!-- JQUERY SELECT2 INPUT -->
	<script src="<?php echo assetsJS; ?>plugin/select2/select2.min.js"></script>

	<!-- JQUERY UI + Bootstrap Slider -->
	<script src="<?php echo assetsJS; ?>plugin/bootstrap-slider/bootstrap-slider.min.js"></script>

	<!-- MAIN APP JS FILE -->
	<script src="<?php echo assetsJS; ?>app.min.js"></script>
	<script src="<?php echo assetsJS; ?>speech/voicecommand.min.js"></script>
	<script src="<?php echo assetsJS; ?>smart-chat-ui/smart.chat.ui.min.js"></script>
	<script src="<?php echo assetsJS; ?>smart-chat-ui/smart.chat.manager.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/flot/jquery.flot.cust.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/flot/jquery.flot.resize.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/flot/jquery.flot.time.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/flot/jquery.flot.tooltip.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/vectormap/jquery-jvectormap-1.2.2.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/vectormap/jquery-jvectormap-world-mill-en.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/moment/moment.min.js"></script>
	<script src="<?php echo assetsJS; ?>plugin/fullcalendar/jquery.fullcalendar.min.js"></script>
	<script src="<?php echo assetsJS; ?>crimeReporting.js"></script>

	<!-- GOOGLE ANALYTIC CODE -->
	<script type="text/javascript">
		var _gaq = _gaq || [];
		_gaq.push(['_setAccount', 'UA-XXXXXXXX-X']);
		_gaq.push(['_trackPageview']);

		(function() {
			var ga = document.createElement('script');
			ga.type = 'text/javascript';
			ga.async = true;
			ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
			var s = document.getElementsByTagName('script')[0];
			s.parentNode.insertBefore(ga, s);
		})();
	</script>
	</body>
</html>