<body class="">
	<!-- HEADER -->
	<header id="header">
		<div id="logo-group">
		</div>
		<div class="pull-right">
			<div id="logout" class="btn-header transparent pull-right">
				<span> <a href="login.html" title="Sign Out" data-action="userLogout" data-logout-msg="You can improve your security further after logging out by closing this opened browser"><i class="fa fa-sign-out"></i></a> </span>
			</div>
		</div>
	</header>
	<aside id="left-panel">
		<nav>
			<ul>
				<li class="active">
					<a href="<?php echo baseUrl; ?>" title="Dashboard"><i class="fa fa-lg fa-fw fa-home"></i> <span class="menu-item-parent">Dashboard</span></a>
				</li>
				<!-- <li>
					<a href="#"><i class="fa fa-lg fa-fw fa-bar-chart-o"></i> <span class="menu-item-parent">User Management</span></a>
					<ul>
						<li>
							<a href="usercreate.html">Create User</a>
						</li>
						<li>
							<a href="userlist.html">List User</a>
						</li>
					</ul>
				</li> -->
				<li>
					<a href="#"><i class="fa fa-lg fa-fw fa-bar-chart-o"></i> <span class="menu-item-parent">Crime Report</span></a>
					<ul>
						<li>
							<a href="<?php echo baseUrl.'crime-listing.php'; ?>">List Crime</a>
						</li>
					</ul>
				</li>
			</ul>
		</nav>
		<span class="minifyme" data-action="minifyMenu"> 
			<i class="fa fa-arrow-circle-left hit"></i> 
		</span>
	</aside>